<?php

include_once "../entities/Personne.php";
include_once "../repository/DB.php";
include_once "../repository/Fonction.php";
$nbSymptôme = 0; 
$nbPositive = 0;
$nbNégative = 0;
$cpt=0;


if(isset($_POST['submit']))
{
    extract($_POST);

    $personne = new Personne;

    $personne->setNomP($_POST['nomP']);
    $personne->setPrenomP($_POST['prenomP']);
    $personne->setNumTel($_POST['numTel']);
    $personne->setAdresse($_POST['adresse']);
    $personne->setSexe($_POST['sexe']);
    $personne->setRésultat($_POST['résultat']);
    if ($_POST['résultat']== "positive"){
       $cpt+= 1;
    }
    if ($_POST['résultat']== "négative"){
        $nbNégative++;
    }
    if ($_POST['résultat']== "symptômatique"){
        $nbSymptôme++;
    }
 
    $sdb = new Fonction();

    $sdb->insertPersonne($personne);

    //header("location:http://localhost/Epidemia/src/views/showPersonne.php");
    echo $cpt;
    echo $nbNégative;
    echo $nbSymptôme;
}