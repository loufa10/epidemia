<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pays Registration</title>
</head>
<body>
    <form action="http://localhost:8080/Epidemia/src/controller/PaysController.php" method="post">
        <div>
            <label for=""><b>Nom Pays : </b></label>
            <input type="text" name="nom"/>
        </div>
        <br>
        <div>
            <label for=""><b>PopulationTotal : </b></label>
            <input type="text" name="population" />
        </div>
        <br>
        <div>
            <label for=""><b>listeZone : </b></label>
            <input type="text" name="listezone"/>
        </div>
        <br>
        <div>
            <input type="submit" name="submit" value="Register"/>
            <input type="reset" name="reset" value="Cancel"/>
        </div>
    </form>
</body>
</html>