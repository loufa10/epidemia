<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zone Registration</title>
</head>
<body>
    <form action="http://localhost:8080/Epidemia/src/controller/ZoneController.php" method="post">
        <div>
            <label for=""><b>Nom Zone : </b></label>
            <input type="text" name="nom"/>
        </div>
        <br>
        <div>
            <label for=""><b>Nombre PersonneSyntome : </b></label>
            <input type="text" name="nombreps" />
        </div>
        <br>
        <div>
            <label for=""><b>Nombre PersonnePositive : </b></label>
            <input type="text" name="nombrepp"/>
        </div>
        <br>
        <div>
            <input type="submit" name="submit" value="Register"/>
            <input type="reset" name="reset" value="Cancel"/>
        </div>
    </form>
</body>
</html>