<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        form {
  background-color: #f2f2f2;
  border: 2px solid #ddd;
  border-radius: 10px;
  padding: 20px;
  margin: 50px auto;
  max-width: 500px;
}

label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
}

input[type="text"], input[type="number"], select {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  margin-bottom: 20px;
  box-sizing: border-box;
}

input[type="submit"], input[type="reset"] {
  background-color: #4CAF50;
  color: #fff;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  margin-right: 10px;
}

input[type="reset"] {
  background-color: #f44336;
}

input[type="submit"]:hover, input[type="reset"]:hover {
  background-color: #3e8e41;
}

input[type="submit"]:focus, input[type="reset"]:focus {
  outline: none;
}

.error {
  color: #f44336;
  font-size: 0.8em;
  margin-top: 5px;
}

    </style>
</head>
<body>
    <form action="http://localhost/Epidemia/src/controller/PersonneController.php" method="post">
        <div>
            <label for=""><b>Nom : </b></label>
            <input type="text" name="nomP"/>
        </div>
        <br>
        <div>
            <label for=""><b>Prenom : </b></label>
            <input type="text" name="prenomP" />
           
        </div>
        <br>
        <div>
            <label for=""><b>Numero de telephone : </b></label>
            <input type="number" name="numTel"/>
        </div>
        <br>
        <div>
            <label for=""><b>Adresse : </b></label>
            <input type="text" name="adresse" />
        </div>
        <br>
        <div>
            <label for=""><b>Sexe : </b></label>
            <input type="text" name="sexe" />
        </div>
        <br>
        <div>
            <label for=""><b>Résultat: </b></label>
            <select name="résultat"> 
                <option value="positive"> positive </option>
                <option value="négative"> négative</option>
                <option value="symptômatique">symptômatique</option>
            </select>
        </div>
        <br>
        <div>
            <input type="submit" name="submit" value="Register"/>
            <input type="reset" name="reset" value="Cancel"/>
        </div>
    </form>
</body>
</html>